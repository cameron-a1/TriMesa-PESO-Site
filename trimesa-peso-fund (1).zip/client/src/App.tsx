import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Header from "./components/Header";
import Footer from "./components/Footer";
import CookieBanner from "./components/CookieBanner";
import Home from "./pages/Home";
import PesoFund from "./pages/PesoFund";
import GovernanceESG from "./pages/GovernanceESG";
import Insights from "./pages/Insights";
import Contact from "./pages/Contact";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/peso-fund"} component={PesoFund} />
      <Route path={"/platform"}>
        {() => {
          window.location.href = "/peso-fund";
          return null;
        }}
      </Route>
      <Route path={"/funds"}>
        {() => {
          window.location.href = "/peso-fund";
          return null;
        }}
      </Route>
      <Route path={"/governance-esg"} component={GovernanceESG} />
      <Route path={"/insights"} component={Insights} />
      <Route path={"/contact"} component={Contact} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <div className="min-h-screen flex flex-col">
            <Header />
            <main className="flex-1">
              <Router />
            </main>
            <Footer />
            <CookieBanner />
          </div>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
